#Write a shell script to create bz2 z.Pass the directory as CLA.

#!/bin/bash

echo "Enter the name of directory"
read name
files=($(find /home/sois/))
bzip2 $name.zip "${files[@]}"
