#Write a shell script to create tar.Pass the directory as CLA.
#!/bin/bash

echo "Enter the name of directory"
read name
files=($(find /home/sois/))
tar -zcf $name.tar "${files[@]}"
