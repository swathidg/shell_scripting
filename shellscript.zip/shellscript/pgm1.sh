find . -mindepth 1 -type d | wc -l

